
# coding: utf-8

# # Object Oriented Programming
# ## Homework Assignment
# 
# ####Problem 1
# Fill in the Line class methods to accept coordinate as a pair of tuples and return the slope and distance of the line.

# In[18]:

class Line(object):
    
    def __init__(self,coor1,coor2):
        pass
    
    def distance(self):
        pass
    
    def slope(self):
        pass


# In[ ]:

# EXAMPLE OUTPUT

coordinate1 = (3,2)
coordinate2 = (8,10)

li = Line(coordinate1,coordinate2)


# In[20]:

li.distance()


# In[21]:

li.slope()


# ________
# ####Problem 2

# Fill in the class 

# In[31]:

class Cylinder(object):
    
    def __init__(self,height=1,radius=1):
        pass
        
    def volume(self):
        pass
    
    def surface_area(self):
        pass


# In[32]:

# EXAMPLE OUTPUT
c = Cylinder(2,3)


# In[34]:

c.volume()


# In[35]:

c.surface_area()


# In[ ]:



