
# coding: utf-8

# # Statements Assessment Test
# Lets test your knowledge!

# _____
# **Use for, split(), and if to create a Statement that will print out words that start with 's':**

# In[3]:

st = 'Print only the words that start with s in this sentence'


# In[1]:

#Code here


# ______
# **Use range() to print all the even numbers from 0 to 10.**

# In[2]:

#Code Here


# ___
# **Use List comprehension to create a list of all numbers between 1 and 50 that are divisible by 3.**

# In[3]:

#Code in this cell
[]


# _____
# **Go through the string below and if the length of a word is even print "even!"**

# In[6]:

st = 'Print every word in this sentence that has an even number of letters'


# In[4]:

#Code in this cell


# ____
# **Write a program that prints the integers from 1 to 100. But for multiples of three print "Fizz" instead of the number, and for the multiples of five print "Buzz". For numbers which are multiples of both three and five print "FizzBuzz".**

# In[ ]:

#Code in this cell


# ____
# **Use List Comprehension to create a list of the first letters of every word in the string below:**

# In[8]:

st = 'Create a list of the first letters of every word in this string'


# In[5]:

#Code in this cell


# ### Great Job!
