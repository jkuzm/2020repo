
# coding: utf-8

# #Advanced Numbers
# In this lecture we will learn about a few more representations of numbers in Python.

# ##Hexadecimal
# 
# Using the function hex() you can convert numbers into a [hexadecimal](https://en.wikipedia.org/wiki/Hexadecimal) format:

# In[4]:

hex(246)


# In[5]:

hex(512)


# ##Binary 
# Using the function bin() you can convert numbers into their [binary](https://en.wikipedia.org/wiki/Binary_number) format.

# In[19]:

bin(1234)


# In[18]:

bin(128)


# In[16]:

bin(512)


# ##pow()
# With two arguments, equivalent to x^y.  With three arguments,
# equivalent to (x^y) % z, but may be more efficient (e.g. for longs).

# In[8]:

pow(2,4)


# ##abs
# Absolute Value

# In[9]:

abs(-3)


# In[10]:

abs(3)


# ##round
# Round a number to a given precision in decimal digits (default 0 digits).
# This always returns a floating point number. 

# In[11]:

round(3)


# In[13]:

round(3.1415926535,2)


# Python has a built-in math library that is also useful to play around with in case you are ever in need of some mathematical operations. Explore the documentation [here](https://docs.python.org/2/library/math.html)!
